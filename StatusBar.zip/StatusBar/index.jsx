
export function StatusBar(){
    return (
       <StatusBar style="light" />
    )
}